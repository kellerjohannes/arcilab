Arciorgano
universal-7-limit
cj walter

Events 1: cjw mode frequencies

Events 2: pure ratio frequencies

Sequences:
Individual events set to 2s duration for testing purposes.

Automation:
automate sequences in any order, indicate absolute start time.

Keyboard map:

can set any key to play:

e = single event, with manual sustain/release
s = sequence as coded in that sequence#
a = will trigger the automation# set here

In the patch itself, you can access the Events and Keyboard map, and change and overwrite.